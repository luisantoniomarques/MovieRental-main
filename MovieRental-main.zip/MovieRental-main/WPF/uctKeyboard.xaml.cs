﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace ArgusLt.UserControls
{
    /// <summary>
    /// Interaction logic for uctKeyboard.xaml
    /// </summary>
    public partial class uctKeyboard : UserControl
    {
        public uctKeyboard()
        {
            InitializeComponent();
            Keyboard.AddKeyDownHandler(this, Keyboard_KeyDown);
            Keyboard.AddKeyUpHandler(this, Keyboard_KeyUp);
        }

        public TextBox ParentControlT { get; set; }
        public PasswordBox ParentControlP { get; set; }

        //private void Window_Loaded(object sender, RoutedEventArgs e)
        //{
        //    Point virtualpoint;
        //    Point Actualpoint = new Point(0, 0);

        //    if (ParentControlT != null)
        //    {
        //        virtualpoint = new Point(0, ParentControlT.ActualHeight + 3);
        //        Actualpoint = ParentControlT.PointToScreen(virtualpoint);
        //    }

        //    if (ParentControlP != null)
        //    {
        //        virtualpoint = new Point(0, ParentControlP.ActualHeight + 3);
        //        Actualpoint = ParentControlP.PointToScreen(virtualpoint);
        //    }

        //    if (this.Width + Actualpoint.X > SystemParameters.VirtualScreenWidth)
        //    {
        //        double difference = this.Width + Actualpoint.X - SystemParameters.VirtualScreenWidth;
        //        this.Left = Actualpoint.X - difference;
        //    }
        //    else if (!(Actualpoint.X > 1))
        //    {
        //        this.Left = 1;
        //    }
        //    else
        //        this.Left = Actualpoint.X;

        //    this.Top = Actualpoint.Y;
        //}

        public delegate void OnKeypadKeyPressT_EventHandler(object sender, TextBox source, string value);
        public event OnKeypadKeyPressT_EventHandler OnKeypad_KeypressT;
        public delegate void OnKeypadKeyPressP_EventHandler(object sender, PasswordBox source, string value);
        public event OnKeypadKeyPressP_EventHandler OnKeypad_KeypressP;

        public delegate void OnKeypadKeyDownT_EventHandler(object sender, TextBox source, Key value);
        public event OnKeypadKeyDownT_EventHandler OnKeypad_KeyDownT;
        public delegate void OnKeypadKeyDownP_EventHandler(object sender, PasswordBox source, Key value);
        public event OnKeypadKeyDownP_EventHandler OnKeypad_KeyDownP;

        private bool _capsLockOn = false;
        private bool _shiftPressed = false;
        private bool _ctlAltPressed = false;

        private void SetCapsContent()
        {
            this.btnSlash.Content = _capsLockOn ? "|" : "\\";
            this.btnD1.Content = _capsLockOn ? "!" : "1";
            this.btnD2.Content = _capsLockOn ? "\"" : "2";
            this.btnD3.Content = _capsLockOn ? "#" : "3";
            this.btnD4.Content = _capsLockOn ? "$" : "4";
            this.btnD5.Content = _capsLockOn ? "%" : "5";
            this.btnD6.Content = _capsLockOn ? "&" : "6";
            this.btnD7.Content = _capsLockOn ? "/" : "7";
            this.btnD8.Content = _capsLockOn ? "(" : "8";
            this.btnD9.Content = _capsLockOn ? ")" : "9";
            this.btnD0.Content = _capsLockOn ? "=" : "0";
            this.btnApos.Content = _capsLockOn ? "?" : "'";
            this.btnDblMinour.Content = _capsLockOn ? "»" : "«";

            this.btnQ.Content = _capsLockOn ? "Q" : "q";
            this.btnW.Content = _capsLockOn ? "W" : "w";
            this.btnE.Content = _capsLockOn ? "E" : "e";
            this.btnR.Content = _capsLockOn ? "R" : "r";
            this.btnT.Content = _capsLockOn ? "T" : "t";
            this.btnY.Content = _capsLockOn ? "Y" : "y";
            this.btnU.Content = _capsLockOn ? "U" : "u";
            this.btnI.Content = _capsLockOn ? "I" : "i";
            this.btnO.Content = _capsLockOn ? "O" : "o";
            this.btnP.Content = _capsLockOn ? "P" : "p";
            this.btnPlus.Content = _capsLockOn ? "*" : "+";
            //this.btnAccent.Content = _capsLockOn ? "´" : "`";

            this.btnA.Content = _capsLockOn ? "A" : "a";
            this.btnS.Content = _capsLockOn ? "S" : "s";
            this.btnD.Content = _capsLockOn ? "D" : "d";
            this.btnF.Content = _capsLockOn ? "F" : "f";
            this.btnG.Content = _capsLockOn ? "G" : "g";
            this.btnH.Content = _capsLockOn ? "H" : "h";
            this.btnJ.Content = _capsLockOn ? "J" : "j";
            this.btnK.Content = _capsLockOn ? "K" : "k";
            this.btnL.Content = _capsLockOn ? "L" : "l";
            this.btnC2.Content = _capsLockOn ? "Ç" : "ç";
            this.btnAO.Content = _capsLockOn ? "ª" : "º";
            //this.btnTile.Content = _capsLockOn ? "^" : "~";

            this.btnMajorMinor.Content = _capsLockOn ? ">" : "<";
            this.btnZ.Content = _capsLockOn ? "Z" : "z";
            this.btnX.Content = _capsLockOn ? "X" : "x";
            this.btnC.Content = _capsLockOn ? "C" : "c";
            this.btnV.Content = _capsLockOn ? "V" : "v";
            this.btnB.Content = _capsLockOn ? "B" : "b";
            this.btnN.Content = _capsLockOn ? "N" : "n";
            this.btnM.Content = _capsLockOn ? "M" : "m";
            this.btnComma.Content = _capsLockOn ? ";" : ",";
            this.btnDot.Content = _capsLockOn ? ":" : ".";
            this.btnMinus.Content = _capsLockOn ? "_" : "-";
        }

        private void SetAltContent()
        {
            this.btnSlash.Content = string.Empty;
            this.btnD1.Content = string.Empty;
            this.btnD2.Content = "@";
            this.btnD3.Content = "£";
            this.btnD4.Content = "§";
            this.btnD5.Content = string.Empty;
            this.btnD6.Content = string.Empty;
            this.btnD7.Content = "{";
            this.btnD8.Content = "[";
            this.btnD9.Content = "]";
            this.btnD0.Content = "}";
            this.btnApos.Content = string.Empty;
            this.btnDblMinour.Content = string.Empty;

            this.btnQ.Content = string.Empty;
            this.btnW.Content = string.Empty;
            this.btnE.Content = "€";
            this.btnR.Content = string.Empty;
            this.btnT.Content = string.Empty;
            this.btnY.Content = string.Empty;
            this.btnU.Content = string.Empty;
            this.btnI.Content = string.Empty;
            this.btnO.Content = string.Empty;
            this.btnP.Content = string.Empty;
            this.btnPlus.Content = "¨";
            //this.btnAccent.Content = string.Empty;

            this.btnA.Content = string.Empty;
            this.btnS.Content = string.Empty;
            this.btnD.Content = string.Empty;
            this.btnF.Content = string.Empty;
            this.btnG.Content = string.Empty;
            this.btnH.Content = string.Empty;
            this.btnJ.Content = string.Empty;
            this.btnK.Content = string.Empty;
            this.btnL.Content = string.Empty;
            this.btnC2.Content = string.Empty;
            this.btnAO.Content = string.Empty;
            //this.btnTile.Content = string.Empty;

            this.btnMajorMinor.Content = string.Empty;
            this.btnZ.Content = string.Empty;
            this.btnX.Content = string.Empty;
            this.btnC.Content = string.Empty;
            this.btnV.Content = string.Empty;
            this.btnB.Content = string.Empty;
            this.btnN.Content = string.Empty;
            this.btnM.Content = string.Empty;
            this.btnComma.Content = string.Empty;
            this.btnDot.Content = string.Empty;
            this.btnMinus.Content = string.Empty;
        }

        private List<ToggleButton> _pressedButtons = new List<ToggleButton>();

        private void btnChar_Click(object sender, RoutedEventArgs e)
        {
            string value = string.Empty;
            ToggleButton btn = (ToggleButton) sender;
            if (btn.Name == "btnReturn")
            {
                if (this.ParentControlT != null)
                {
                    if (OnKeypad_KeyDownT != null)
                        OnKeypad_KeyDownT(this, this.ParentControlT, Key.Back);
                }
                if (this.ParentControlP != null)
                {
                    if (OnKeypad_KeyDownP != null)
                        OnKeypad_KeyDownP(this, this.ParentControlP, Key.Back);
                }
            }
            else if (btn.Name == "btnEsc")
            {
                if (this.ParentControlT != null)
                {
                    if (OnKeypad_KeyDownT != null)
                        OnKeypad_KeyDownT(this, this.ParentControlT, Key.Escape);
                }
                if (this.ParentControlP != null)
                {
                    if (OnKeypad_KeyDownP != null)
                        OnKeypad_KeyDownP(this, this.ParentControlP, Key.Escape);
                }
            }
            else if (btn.Name == "btnTab")
            {
                if (this.ParentControlT != null)
                {
                    if (OnKeypad_KeyDownT != null)
                        OnKeypad_KeyDownT(this, this.ParentControlT, Key.Tab);
                }
                if (this.ParentControlP != null)
                {
                    if (OnKeypad_KeyDownP != null)
                        OnKeypad_KeyDownP(this, this.ParentControlP, Key.Tab);
                }
            }
            else
            {
                value = (string) btn.Content;
            }

            if (!_pressedButtons.Contains(btn)) _pressedButtons.Add(btn);

            if (this.ParentControlT != null)
            {
                if (OnKeypad_KeypressT != null)
                    OnKeypad_KeypressT(this, this.ParentControlT, value);
            }
            if (this.ParentControlP != null)
            {
                if (OnKeypad_KeypressP != null)
                    OnKeypad_KeypressP(this, this.ParentControlP, value);
            }

            if (_shiftPressed)
            {
                _shiftPressed = false;
                _capsLockOn = false;
                if (!_pressedButtons.Contains(this.btnShiftL)) _pressedButtons.Add(this.btnShiftL);
                if (!_pressedButtons.Contains(this.btnShiftR)) _pressedButtons.Add(this.btnShiftR);
                if (!_pressedButtons.Contains(this.btnCapsLock)) _pressedButtons.Add(this.btnCapsLock);
                SetCapsContent();
            }
            if (_ctlAltPressed)
            {
                _ctlAltPressed = false;
                if (!_pressedButtons.Contains(this.btnShiftL)) _pressedButtons.Add(this.btnCtrAltL);
                if (!_pressedButtons.Contains(this.btnShiftL)) _pressedButtons.Add(this.btnCtrAltR);
                SetCapsContent();
            }

            System.Timers.Timer x = new System.Timers.Timer(100);
            x.Elapsed += new System.Timers.ElapsedEventHandler(x_Elapsed);
            x.Start();
        }

        void x_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(ReleaseButtons));
        }

        private void ReleaseButtons()
        {
            while (_pressedButtons.Count > 0)
            {
                foreach (ToggleButton btn in _pressedButtons)
                {
                    btn.IsChecked = false;
                    _pressedButtons.Remove(btn);
                    break;
                }
            }
        }

        private void btnShift_Checked(object sender, RoutedEventArgs e)
        {
            _capsLockOn = true;
            _shiftPressed = true;
            SetCapsContent();
        }

        private void btnShift_Unchecked(object sender, RoutedEventArgs e)
        {
            _capsLockOn = false;
            _shiftPressed = false;
            SetCapsContent();
        }

        private void btnCapsLock_Checked(object sender, RoutedEventArgs e)
        {
            _capsLockOn = true;
            _shiftPressed = false;
            SetCapsContent();
        }

        private void btnCapsLock_Unchecked(object sender, RoutedEventArgs e)
        {
            _capsLockOn = false;
            _shiftPressed = false;
            SetCapsContent();
        }

        private void btnCtrAlt_Checked(object sender, RoutedEventArgs e)
        {
            if (!(bool) this.btnCtrAltL.IsChecked) this.btnCtrAltL.IsChecked = true;
            if (!(bool) this.btnCtrAltR.IsChecked) this.btnCtrAltR.IsChecked = true;
            _ctlAltPressed = true;
            SetAltContent();
        }

        private void btnCtrAlt_Unchecked(object sender, RoutedEventArgs e)
        {
            if ((bool) this.btnCtrAltL.IsChecked) this.btnCtrAltL.IsChecked = false;
            if ((bool) this.btnCtrAltR.IsChecked) this.btnCtrAltR.IsChecked = false;
            _ctlAltPressed = false;
            SetCapsContent();
        }


        private bool _leftCtrlDwn = false;
        private void Keyboard_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.LeftCtrl)
            {
                _leftCtrlDwn = false;
            }
            if (e.Key == Key.RightAlt)
            {
                _leftCtrlDwn = false;
                this.btnCtrAltL.IsChecked = false;
                this.btnCtrAltR.IsChecked = false;
                this.btnCtrAltL.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.UncheckedEvent });
            }
            if (e.Key == Key.LeftShift)
            {
                this.btnShiftL.IsChecked = false;
                this.btnShiftL.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.UncheckedEvent });
            }
            if (e.Key == Key.RightShift)
            {
                this.btnShiftR.IsChecked = false;
                this.btnShiftR.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.UncheckedEvent });
            }
        }

        private void Keyboard_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.DeadCharProcessed)
            {
                e.Handled = false;
                return;
            }
            if (e.Key == Key.Escape || e.Key == Key.Return)
            {
                this.btnEsc.IsChecked = true;
                this.btnEsc.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Back)
            {
                this.btnReturn.IsChecked = true;
                this.btnReturn.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Tab)
            {
                this.btnTab.IsChecked = true;
                this.btnTab.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.LeftShift)
            {
                this.btnShiftL.IsChecked = true;
                this.btnShiftL.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.CheckedEvent });
            }
            if (e.Key == Key.RightShift)
            {
                this.btnShiftR.IsChecked = true;
                this.btnShiftR.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.CheckedEvent });
            }
            if (e.Key == Key.LeftCtrl)
            {
                _leftCtrlDwn = true;
            }
            if (e.Key == Key.RightAlt && _leftCtrlDwn)
            {
                _leftCtrlDwn = false;
                this.btnCtrAltL.IsChecked = true;
                this.btnCtrAltR.IsChecked = true;
                this.btnCtrAltL.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.CheckedEvent });
            }

            if (e.Key == Key.CapsLock || e.Key == Key.Capital)
            {
                KeyStates kstC1 = Keyboard.GetKeyStates(Key.CapsLock);
                KeyStates kstC2 = Keyboard.GetKeyStates(Key.Capital);

                if (kstC1 == (KeyStates.Down | KeyStates.Toggled) || kstC2 == (KeyStates.Down | KeyStates.Toggled))
                {
                    this.btnCapsLock.IsChecked = true;
                    this.btnCapsLock.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.CheckedEvent });
                }
                else
                {
                    this.btnCapsLock.IsChecked = false;
                    this.btnCapsLock.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.UncheckedEvent });
                }
            }

            //this.btnSlash.Content = string.Empty;

            if (e.Key == Key.D1)
            {
                this.btnD1.IsChecked = true;
                this.btnD1.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D2)
            {
                this.btnD2.IsChecked = true;
                this.btnD2.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D3)
            {
                this.btnD3.IsChecked = true;
                this.btnD3.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D4)
            {
                this.btnD4.IsChecked = true;
                this.btnD4.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D5)
            {
                this.btnD5.IsChecked = true;
                this.btnD5.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D6)
            {
                this.btnD6.IsChecked = true;
                this.btnD6.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D7)
            {
                this.btnD7.IsChecked = true;
                this.btnD7.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D8)
            {
                this.btnD8.IsChecked = true;
                this.btnD8.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D9)
            {
                this.btnD9.IsChecked = true;
                this.btnD9.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D0)
            {
                this.btnD0.IsChecked = true;
                this.btnD0.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }

            //Console.WriteLine(e.Key.ToString());
            if (e.Key == Key.Oem5)
            {
                this.btnSlash.IsChecked = true;
                this.btnSlash.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.OemOpenBrackets)
            {
                this.btnApos.IsChecked = true;
                this.btnApos.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Oem6)
            {
                this.btnDblMinour.IsChecked = true;
                this.btnDblMinour.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }

            if (e.Key == Key.OemPlus)
            {
                this.btnPlus.IsChecked = true;
                this.btnPlus.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }

            //if (e.Key == Key.Oem1)
            //{
            //    this.btnAccent.IsChecked = true;
            //    this.btnAccent.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            //}
            if (e.Key == Key.Oem7)
            {
                this.btnAO.IsChecked = true;
                this.btnAO.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            //if (e.Key == Key.OemQuestion)
            //{
            //    this.btnTile.IsChecked = true;
            //    this.btnTile.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            //}
            if (e.Key == Key.OemBackslash)
            {
                this.btnMajorMinor.IsChecked = true;
                this.btnMajorMinor.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.OemComma)
            {
                this.btnComma.IsChecked = true;
                this.btnComma.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.OemPeriod)
            {
                this.btnDot.IsChecked = true;
                this.btnDot.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.OemMinus)
            {
                this.btnMinus.IsChecked = true;
                this.btnMinus.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Oem3)
            {
                this.btnC2.IsChecked = true;
                this.btnC2.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }


            if (e.Key == Key.Q)
            {
                this.btnQ.IsChecked = true;
                this.btnQ.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.W)
            {
                this.btnW.IsChecked = true;
                this.btnW.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.E)
            {
                this.btnE.IsChecked = true;
                this.btnE.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.R)
            {
                this.btnR.IsChecked = true;
                this.btnR.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.T)
            {
                this.btnT.IsChecked = true;
                this.btnT.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Y)
            {
                this.btnY.IsChecked = true;
                this.btnY.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.U)
            {
                this.btnU.IsChecked = true;
                this.btnU.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.I)
            {
                this.btnI.IsChecked = true;
                this.btnI.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.O)
            {
                this.btnO.IsChecked = true;
                this.btnO.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.P)
            {
                this.btnP.IsChecked = true;
                this.btnP.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.A)
            {
                this.btnA.IsChecked = true;
                this.btnA.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.S)
            {
                this.btnS.IsChecked = true;
                this.btnS.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.D)
            {
                this.btnD.IsChecked = true;
                this.btnD.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.F)
            {
                this.btnF.IsChecked = true;
                this.btnF.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.G)
            {
                this.btnG.IsChecked = true;
                this.btnG.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.H)
            {
                this.btnH.IsChecked = true;
                this.btnH.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.J)
            {
                this.btnJ.IsChecked = true;
                this.btnJ.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.K)
            {
                this.btnK.IsChecked = true;
                this.btnK.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.L)
            {
                this.btnL.IsChecked = true;
                this.btnL.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.Z)
            {
                this.btnZ.IsChecked = true;
                this.btnZ.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.X)
            {
                this.btnX.IsChecked = true;
                this.btnX.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.C)
            {
                this.btnC.IsChecked = true;
                this.btnC.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.V)
            {
                this.btnV.IsChecked = true;
                this.btnV.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.B)
            {
                this.btnB.IsChecked = true;
                this.btnB.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.N)
            {
                this.btnN.IsChecked = true;
                this.btnN.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
            if (e.Key == Key.M)
            {
                this.btnM.IsChecked = true;
                this.btnM.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }

            if (e.Key == Key.Space)
            {
                this.btnSpace.IsChecked = true;
                this.btnSpace.RaiseEvent(new RoutedEventArgs() { RoutedEvent = ToggleButton.ClickEvent });
            }
        }
    }
}
