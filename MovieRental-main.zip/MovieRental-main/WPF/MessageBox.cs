﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;

namespace ArgusLt.csMessageBox
{
    public class CustomMessageBox
    {
        #region  Private Declarations

        private static MessageBoxButtons _enumButtons = MessageBoxButtons.OK;
        private static MessageBoxResults _enumCustomDialogResult = MessageBoxResults.None;
        private static MessageBoxResults _enumDefaultButton = MessageBoxResults.None;
        //private static MessageBoxIcons _enumIcon = MessageBoxIcons.None;
        private static string _strCaption = String.Empty;
        private static string _strText = String.Empty;

        private static string _strCallingMethodName = String.Empty;          //example:  "btnDashboard_Click"
        private static string _strCallingModuleName = String.Empty;          //example:  "CustomDialogSample.exe"
        private static string _strCallingReflectedTypeName = String.Empty;   //example:  "ApplicationMainWindow"	
        #endregion


        #region  Methods
        /// <summary>
        ///     Shows the custom dialog described by the constructor and properties set by the caller, returns CustomDialogResults.
        /// </summary>
        /// <returns>
        ///     A WpfCustomMsgBoxResults value.
        /// </returns>
        public static MessageBoxResults Show(string text, MessageBoxButtons buttons, MessageBoxResults defaultButton = MessageBoxResults.None)
        {
            _enumButtons = buttons;
            _enumDefaultButton = defaultButton;
            //_enumIcon = icon;
            //_strCaption = caption;
            _strText = text;

            //get the calling code information
            System.Diagnostics.StackTrace objTrace = new System.Diagnostics.StackTrace();
            if (_strCallingReflectedTypeName.Length == 0)
                _strCallingReflectedTypeName = objTrace.GetFrame(1).GetMethod().ReflectedType.Name;

            if (_strCallingMethodName.Length == 0)
                _strCallingMethodName = objTrace.GetFrame(1).GetMethod().Name;


            if (_strCallingModuleName.Length == 0)
                _strCallingModuleName = objTrace.GetFrame(1).GetMethod().Module.Name;


            MessageBox obj = new MessageBox();
            obj.Title = _strCaption;
            obj._txtText.Text = _strText;

            SetButtons(obj);

            obj.ShowInTaskbar = false;
            if (obj.Parent == null)
            {
                obj.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            }
            else
            {
                obj.Owner = (Window) obj.Parent;
                obj.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterOwner;
            }
            obj.ShowDialog();
            _enumCustomDialogResult = obj.CustomDialogResult;

            LogDialog();

            return _enumCustomDialogResult;
        }

        private static void LogDialog()
        {
            //TODO - developers, you can log the result here.  There is rich information within this class to provides great tracking of your users dialog box activities.
            //ensure that you review each property and include them in your log entry
            //don't forget to log the Windows user name also
        }

        private static void SetButtons(MessageBox obj)
        {
            switch (_enumButtons)
            {
                case MessageBoxButtons.AbortRetryIgnore:
                    obj._btnNo.Visibility = Visibility.Collapsed;
                    obj._btnYes.Visibility = Visibility.Collapsed;
                    obj._btnOk.Visibility = Visibility.Collapsed;
                    obj._btnCancel.Visibility = Visibility.Collapsed;
                    break;

                case MessageBoxButtons.OK:
                    obj._btnNo.Visibility = Visibility.Collapsed;
                    obj._btnYes.Visibility = Visibility.Collapsed;
                    obj._btnCancel.Visibility = Visibility.Collapsed;
                    obj._btnAbort.Visibility = Visibility.Collapsed;
                    obj._btnRetry.Visibility = Visibility.Collapsed;
                    obj._btnIgnore.Visibility = Visibility.Collapsed;
                    break;

                case MessageBoxButtons.OKCancel:
                    obj._btnNo.Visibility = Visibility.Collapsed;
                    obj._btnYes.Visibility = Visibility.Collapsed;
                    obj._btnAbort.Visibility = Visibility.Collapsed;
                    obj._btnRetry.Visibility = Visibility.Collapsed;
                    obj._btnIgnore.Visibility = Visibility.Collapsed;
                    break;

                case MessageBoxButtons.RetryCancel:
                    obj._btnNo.Visibility = Visibility.Collapsed;
                    obj._btnYes.Visibility = Visibility.Collapsed;
                    obj._btnOk.Visibility = Visibility.Collapsed;
                    obj._btnAbort.Visibility = Visibility.Collapsed;
                    obj._btnIgnore.Visibility = Visibility.Collapsed;
                    break;

                case MessageBoxButtons.YesNo:
                    obj._btnOk.Visibility = Visibility.Collapsed;
                    obj._btnCancel.Visibility = Visibility.Collapsed;
                    obj._btnAbort.Visibility = Visibility.Collapsed;
                    obj._btnRetry.Visibility = Visibility.Collapsed;
                    obj._btnIgnore.Visibility = Visibility.Collapsed;
                    break;

                case MessageBoxButtons.YesNoCancel:
                    obj._btnOk.Visibility = Visibility.Collapsed;
                    obj._btnAbort.Visibility = Visibility.Collapsed;
                    obj._btnRetry.Visibility = Visibility.Collapsed;
                    obj._btnIgnore.Visibility = Visibility.Collapsed;
                    break;

                default:
                    throw new System.ArgumentOutOfRangeException("Buttons", _enumButtons.ToString(), "Programmer did not program for this selection.");
            }

            obj._btnAbort.IsDefault = false;
            obj._btnCancel.IsDefault = false;
            obj._btnIgnore.IsDefault = false;
            obj._btnNo.IsDefault = false;
            obj._btnOk.IsDefault = false;
            obj._btnRetry.IsDefault = false;
            obj._btnYes.IsDefault = false;

            switch (_enumDefaultButton)
            {
                case MessageBoxResults.Abort:
                    obj._btnAbort.IsDefault = true;
                    break;
                case MessageBoxResults.Ignore:
                    obj._btnIgnore.IsDefault = true;
                    break;
                case MessageBoxResults.Retry:
                    obj._btnRetry.IsDefault = true;
                    break;
                case MessageBoxResults.Cancel:
                    obj._btnCancel.IsDefault = true;
                    break;
                case MessageBoxResults.No:
                    obj._btnNo.IsDefault = true;
                    break;
                case MessageBoxResults.None:
                    obj._btnCancel.IsCancel = true;
                    break;
                case MessageBoxResults.OK:
                    obj._btnOk.IsDefault = true;
                    break;
                case MessageBoxResults.Yes:
                    obj._btnYes.IsDefault = true;
                    break;
                default:
                    throw new System.ArgumentOutOfRangeException("DefaultButton", _enumDefaultButton.ToString(), "Programmer did not program for this selection.");
            }
        }
        #endregion
    }
}
