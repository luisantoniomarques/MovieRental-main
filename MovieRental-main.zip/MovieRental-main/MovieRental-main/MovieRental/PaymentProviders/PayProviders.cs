﻿using Microsoft.VisualBasic;

namespace MovieRental.PaymentProviders
{
    public class PayProviders
    {
        //A class that brings together the various payers of services.
        public MbWayProvider mbProv;
        public PayPalProvider PayPal;
        // Other providers
    }
}
