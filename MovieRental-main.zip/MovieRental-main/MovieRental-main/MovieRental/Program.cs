using MovieRental.Data;
using MovieRental.Movie;
using MovieRental.Rental;

try
{
    var builder = WebApplication.CreateBuilder(args);

    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddEntityFrameworkSqlite().AddDbContext<MovieRentalDbContext>();

    builder.Services.AddSingleton<IRentalFeatures, RentalFeatures>();

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseHttpsRedirection();

    app.UseAuthorization();

    app.MapControllers();

    using (var client = new MovieRentalDbContext())
    {
	    client.Database.EnsureCreated();
    }

    app.Run();
} 

catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
