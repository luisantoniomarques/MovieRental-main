# MovieRental Exercise

This is a dummy representation of a movie rental system.
Can you help us fix some issues and implement missing features?

 * The app is throwing an error when we start, please help us. Also, tell us what caused the issue.
 * The rental class has a method to save, but it is not async, can you make it async and explain to us what is the difference?
 * Please finish the method to filter rentals by customer name, and add the new endpoint.
 * We noticed we do not have a table for customers, it is not good to have just the customer name in the rental.
   Can you help us add a new entity for this? Don't forget to change the customer name field to a foreign key, and fix your previous method!
 * In the MovieFeatures class, there is a method to list all movies, tell us your opinion about it.
 * No exceptions are being caught in this api, how would you deal with these exceptions?


	## Challenge (Nice to have)
We need to implement a new feature in the system that supports automatic payment processing. Given the advancements in technology, it is essential to integrate multiple payment providers into our system.

Here are the specific instructions for this implementation:

* Payment Provider Classes:
    * In the "PaymentProvider" folder, you will find two classes that contain basic (dummy) implementations of payment providers. These can be used as a starting point for your work.
* RentalFeatures Class:
    * Within the RentalFeatures class, you are required to implement the payment processing functionality.
* Payment Provider Designation:
    * The specific payment provider to be used in a rental is specified in the Rental model under the attribute named "PaymentMethod".
* Extensibility:
    * The system should be designed to allow the addition of more payment providers in the future, ensuring flexibility and scalability.
* Payment Failure Handling:
    * If the payment method fails during the transaction, the system should prevent the creation of the rental record. In such cases, no rental should be saved to the database.




------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





# MovieRental Exercise
Esta é uma representação fictícia de um sistema de aluguer de filmes.
Pode ajudar-nos a corrigir alguns problemas e implementar recursos que faltam?

* A aplicação está a apresentar um erro ao iniciar. Por favor, ajude-nos. Além disso, informe-nos qual foi a causa do problema.
* A classe `Rental` possui um método para guardar, mas não é assíncrono. Pode torná-lo assíncrono e explicar-nos a diferença?
* Por favor, finalize o método para filtrar os alugueres por nome do cliente e adicione o novo endpoint.
* Notamos que não temos uma tabela para os clientes. Não é recomendável ter apenas o nome do cliente no aluguer.

Pode ajudar-nos a adicionar uma nova entidade para isso? Não se esqueça de transformar o campo do nome do cliente numa chave estrangeira e corrigir o método anterior!

* Na classe `MovieFeatures`, existe um método para listar todos os filmes. Qual a sua opinião sobre ele?
* Nenhuma exceção está a ser capturada nesta API. Como lidaria com essas exceções?



## Challenge (Nice to have)

Necessitamos de implementar uma nova funcionalidade no sistema que suporte o processamento automático de pagamentos. Devido aos avanços tecnológicos, é essencial integrar múltiplos fornecedores de pagamento no nosso sistema.

Seguem-se as instruções específicas para esta implementação:

* Classes de Fornecedores de Pagamento:
* Na pasta "PaymentProvider", encontrará duas classes que contêm implementações básicas (fictícias) de fornecedores de pagamento. Podem ser utilizadas como ponto de partida para o seu trabalho.

* Classe RentalFeatures:
* Dentro da classe RentalFeatures, terá de implementar a funcionalidade de processamento de pagamentos.
* Designação do Prestador de Pagamento:
* O fornecedor de pagamento específico a utilizar num aluguer é especificado no modelo Rental, no atributo "PaymentMethod".

* Extensibilidade:
* O sistema deve ser concebido para permitir a adição de mais fornecedores de pagamento no futuro, garantindo flexibilidade e escalabilidade.

* Tratamento de Falhas de Pagamento:

Se o método de pagamento falhar durante a transação, o sistema deverá impedir a criação do registo de aluguer. Nestes casos, nenhum aluguer deve ser guardado no banco de dados.
